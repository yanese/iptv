#!/bin/sh
/usr/bin/php /iptv/epg2xml/epg2xml-web.php
