#!/bin/sh
cd /iptv/Klive/klive_server/output
rm klive.xml
wget https://raw.githubusercontent.com/soju6jan/soju6jan.github.io/master/epg/klive.xml
