#!/usr/bin/env php
<?php
include __DIR__."/epg2xml-web.php";
?>
